
import numpy as np
import pandas as pd



column = 'height_dtm'

df = pd.read_pickle('../save2.pkl').reset_index()
print(df)
